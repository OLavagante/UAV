%% Adding ARDrone library to the path
addpath ../lib/ ; 

sampleTime = 1/200;
%%
ARDroneReplay_V2 ; 